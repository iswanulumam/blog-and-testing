<template>
  <div class="col-sm-3 col-sm-offset-1 blog-sidebar">
    <div class="sidebar-module sidebar-module-inset">
      <h4>About</h4>
      <p>My name is <em>Iswanul Umam</em> I am coding for food.</p>
    </div>
    <div class="sidebar-module">
      <h4>Archives</h4>
      <ol class="list-unstyled">
        <li><a href="#">Mei 2018</a></li>
      </ol>
    </div>
    <div class="sidebar-module">
      <h4>Social Link</h4>
      <ol class="list-unstyled">
        <li><a href="https://github.com/iswanulumam">GitHub</a></li>
        <li><a href="https://www.linkedin.com/in/iswanulumam/">LinkedIn</a></li>
      </ol>
    </div>
  </div><!-- /.blog-sidebar -->
</template>

<script>
export default {
  
}
</script>

