<template>
  <div class="blog-footer">
    <p>My name is <a href="https://github.com/iswanulumam"></a> <a href="https://github.com/iswanulumam">@iswanulumam</a>.</p>
    <p>
      <router-link to="/login">Admin (login) |</router-link>
      <router-link to="/admin">Admin (upload) |</router-link>
      <router-link to="/manage">Admin (manage)</router-link>
    </p>
  </div>
</template>