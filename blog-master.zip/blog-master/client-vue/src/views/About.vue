<template>
  <div class ="blog-post">
    <div class="center">
      <img src="https://avatars0.githubusercontent.com/u/11136789?s=460&v=4" style="alirg" alt="Me">
    </div>
    <br>
    <br>
    <p class="lead blog-description">I love programming and happy talk in language such JavaScript (front-end and back-end side). I like growing culture and i am agile (scrum) enthusiast. Agility make engineering culture pretty, and improvement to get a designation Rockstar.</p>
    <p class="lead blog-description">I am also passionate in education of technology and computer science. I have experience in teaching & learning, and has developed a lot of teaching materials and instructional media.</p>
    <p class="lead blog-description">Other side, I love nature especially mountain, I love climb. Climbing has a great philosophy 'to see a beauty must be pursued with endless struggle'.</P>
  </div>
</template>

<style>
img {
    border-radius: 50%;
    width: 333px;
    height: 333px;
}
.center {
    display: block;
    margin-left: auto;
    margin-right: auto;
    width: 50%;
}
</style>
